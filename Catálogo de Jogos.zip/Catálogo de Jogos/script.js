function atualizarContador() {

    const total =
        document.querySelectorAll(".card").length;

    document.getElementById("contador")
            .textContent = total;
}

atualizarContador();

const pesquisa =
    document.getElementById("pesquisa");

pesquisa.addEventListener("keyup", function () {

    const texto =
        pesquisa.value.toLowerCase();

    const jogos =
        document.querySelectorAll(".card");

    jogos.forEach(function (jogo) {

        const titulo =
            jogo.querySelector("h2")
                .textContent
                .toLowerCase();

        if (titulo.includes(texto)) {

            jogo.style.display = "";

        } else {

            jogo.style.display = "none";

        }

    });

});

const adicionarBtn =
    document.getElementById("adicionarBtn");

adicionarBtn.addEventListener("click", function () {

    const campo =
        document.getElementById("novoJogo");

    const nome =
    document.getElementById("novoJogo")
            .value.trim();

    const descricao =
        document.getElementById("descricaoJogo")
                .value.trim();

    const imagem =
        document.getElementById("imagemJogo")
                .value.trim();

    if (nome === "" ||
        descricao === "" ||
        imagem === "") {

        alert("Digite um nome.");
        return;
    }

    const novoCard =
        document.createElement("div");

    novoCard.classList.add("card");

    novoCard.innerHTML = `
    <img src="${imagem}" alt="${nome}">

    <h2>${nome}</h2>

    <p>${descricao}</p>

    <a href="#">Ver mais</a>
`;

    document.getElementById("catalogo").appendChild(novoCard);
    document.getElementById("novoJogo").value = "";
    document.getElementById("descricaoJogo").value = "";
    document.getElementById("imagemJogo").value = "";

    campo.value = "";

    atualizarContador();

});
